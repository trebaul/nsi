from matplotlib.pyplot import *
from random import randint

x = [randint(1,100) for i in range(1000)]
y = [randint(1,100) for i in range(1000)]
scatter(x,y, c='red')  # il faut ici rajouter le nom de paramètre c pour changer la couleur
show()
