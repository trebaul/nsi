from matplotlib.pyplot import *
from random import randint

noms = ['Loup', 'Renard', 'Belette', 'Jument']
tailles = [15, 30, 45, 10]
pie(tailles, labels=noms)
show()
