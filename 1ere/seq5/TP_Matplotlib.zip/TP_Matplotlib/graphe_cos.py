from matplotlib.pyplot import *
from math import cos

abscisses = [i for i in range(100)]
ordonnees = [cos(i) for i in range(100)]    # à compléter - y doit être de taille 100 aussi
plot(abscisses, ordonnees, 'b')
show()
