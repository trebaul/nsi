from matplotlib.pyplot import *

x = [0, 1, 2, 3]
y = [3, 4, -1, 2]
plot(x, y)     # on trace x en foncton de y
show()        # on montre le graphique
