from matplotlib.pyplot import *
from random import randint

liste =[randint(1,6) for _ in range(100)]
hist(liste, 6)
show()
