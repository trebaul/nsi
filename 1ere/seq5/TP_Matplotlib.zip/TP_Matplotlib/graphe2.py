from matplotlib.pyplot import *

x = [i for i in range(100)]  # permet de représenter 100 points
y = [3*i for i in range(100)]  # à compléter - y doit être de taille 100 aussi 
plot(x, y)     # vous pouvez rajouter le 3ème paramètre qui vous convient le mieux
show()        
