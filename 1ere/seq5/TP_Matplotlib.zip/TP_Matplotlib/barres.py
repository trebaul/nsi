from matplotlib.pyplot import *

x = [3, 4, 5, 6, 7]
y = [1, 2, 3, 4, 5]
bar(x, y)
show()
