from matplotlib.pyplot import *

def carre(image, couleur):
    for i in range(1,len(image)-1):
        for j in range(1,len(image[0])-1):
            if couleur == "rouge":
                image[i][j] = (255,0,0)
            elif couleur == "vert":
                image[i][j] = (0,255,0)
            elif couleur == "bleu":
                image[i][j] = (0,0,255)
            elif couleur == "jaune":
                image[i][j] = (255,255,0)
    return image

image = [[(0,0,0) for _ in range(25)] for _ in range(25)]
image = carre(image, "rouge")
imshow(image)
show()