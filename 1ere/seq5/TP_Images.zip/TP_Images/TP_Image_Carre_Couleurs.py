from matplotlib.pyplot import *

# Carrés de différentes couleurs
image = [[(0,0,0) for _ in range(25)] for _ in range(25)]
for i in range(1,len(image)-1):
    for j in range(1,len(image[0])-1):
        if i<len(image)//2 and j<len(image)//2:
            image[i][j] = (255, 0, 0)
        if i<len(image)//2 and j>len(image)//2:
            image[i][j] = (0, 255, 0)
        if i>len(image)//2 and j<len(image)//2:
            image[i][j] = (0, 0, 255)
        if i>len(image)//2 and j>len(image)//2:
            image[i][j] = (255, 255, 0)
            
imshow(image)
show()