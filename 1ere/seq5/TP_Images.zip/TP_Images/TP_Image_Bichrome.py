import matplotlib.pyplot as plt

image = [[0 for _ in range(25)] for _ in range(25)]

# carré
for i in range(len(image)):
    for j in range(len(image[0])):
        if i==0 or i==(len(image)-1) or j==0 or j==(len(image)-1):
            image[i][j] = 1
            
# croix - code à décommenter pour pour faire la première image
# for i in range(len(image)):
#     for j in range(len(image[0])):
#         if i==len(image)//2 or j==len(image)//2:
#             image[i][j] = 1
            
# milieu
for i in range(len(image)):
    for j in range(len(image[0])):
        if i==j:
            image[i][j] = 1

plt.imshow(image)
plt.show()