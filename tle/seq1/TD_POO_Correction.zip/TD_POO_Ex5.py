from math import sqrt

def cree_astre(m, p):
    d = {}
    d["masse"] = m
    d["position"] = p
    return d

def calcule_distance(a1, a2):
    return sqrt((a1["position"][0]-a2["position"][0])**2+(a1["position"][1]-a2["position"][1]))
    
masse_solaire = 2*10**(30)
m1 = 0.07*masse_solaire
m2 = 300*masse_solaire

a1 = cree_astre(m1, [15,34])
a2 = cree_astre(m2, [6,27])
d = calcule_distance(a1,a2)