class Chat:
    def __init__(self):
        self.faim = 0
        self.fatigue = 0

    def bonjour(self, animal):
        if isinstance(animal, Chat):
            print("Miaou !")

    def joue(self):
        self.faim = self.faim+1
        self.fatigue = self.fatigue+1

class Chien:
    def __init__(self):
        self.faim = 0
        self.fatigue = 0

    def bonjour(self, animal):
        if isinstance(animal, Chien):
            print("Ouaf !")
        else:
            print('OUAF !')

    def joue(self):
        self.faim = self.faim+1
        self.fatigue = self.fatigue+1
        
# On peut faire des différences entre l'espèce : ici, un chat miaule alors qu'un chien aboie.

chat = Chat()
chien = Chien()
chat.bonjour(chien)
chat.bonjour(chat)
chien.bonjour(chat)
chien.bonjour(chien)


class Animal:
    def __init__(self, e):
        self.faim = 0
        self.fatigue = 0
        self.espece = e

    def bonjour(self):
        if self.espece == "chat":
            print("Miaou !")
        else:
            print('Ouaf !')

    def joue(self):
        self.faim = self.faim+1
        self.fatigue = self.fatigue+1
        
    def mange(self):
        self.faim -= 1
        
    def repos(self):
        self.fatigue -= 2
        
chat2 = Animal("chat")

