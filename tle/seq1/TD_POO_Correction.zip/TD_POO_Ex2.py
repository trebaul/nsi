from math import sqrt

class Astre:
    '''Corps célestes, définis par leurs propriétés physiques.'''

    def __init__(self, m, p):
        self.masse = m
        self.position = p

    def distance(self, astre):
        return sqrt((self.position[0]-astre.position[0])**2+(self.position[1]-astre.position[1]))
    
masse_solaire = 2*10**(30)
m1 = 0.07*masse_solaire
m2 = 300*masse_solaire

a1 = Astre(m1, [15,34])
a2 = Astre(m2, [6,27])
d = a1.distance(a2)