def separe(l):
    l_entiers = []
    l_str = []
    for e in l:
        if isinstance(e, int):
            l_entiers.append(e)
        elif isinstance(e, str):
            l_str.append(e)
    return l_entiers, l_str

l_e, l_s = separe([1, "a", 666, "blablabla", "nsi"])
