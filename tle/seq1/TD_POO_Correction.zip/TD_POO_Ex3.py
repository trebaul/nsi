class Chat:
    def __init__(self):
        self.__faim = 0
        self.__fatigue = 0
        
    def acc_faim(self):
        return self.__faim
    
    def acc_fatigue(self):
        return self.__fatigue
    
    def modifie_faim(self, fai):
        self.__faim = fai
        
    def modifie_fatigue(self, fat):
        self.__fatigue = fat
        
c = Chat()
f = c.acc_faim()
print(f)
c.modifie_faim(5)
f = c.acc_faim()
print(f)